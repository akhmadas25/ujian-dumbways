<?php
include "header.php";
$id = $_GET['id'];
$data = mysqli_query($koneksi, "select * from book_tb where id='$id'");
while ($d = mysqli_fetch_array($data)) {
?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-3" style="min-height:480px">
                <div class="card">

                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <form method="post" action="update.php">
                                    <div class="from-group">

                                        <label>BOOK</label>
                                        <input type="hidden" class="form-control" name="id" value="<?php echo $d['id']; ?>">
                                        <input type="text" class="form-control" name="nama" value="<?php echo $d['nama']; ?>">

                                        <label>CATEGORY</label>
                                        <input type="text" class="form-control" name="category_id" value="<?php echo $d['category_id']; ?>">

                                        <label>WRITER</label>
                                        <input type="text" class="form-control" name="writer_id" value="<?php echo $d['writer_id']; ?>">

                                        <label>YEAR</label>
                                        <input type="text" class="form-control" name="publication_year" value="<?php echo $d['publication_year']; ?>">

                                    </div>
                                    <td><input type="submit" class="btn btn-alert" value="save"></td>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
}
include "footer.php";
?>