
	<?php
    include "header.php";
    $id = $_POST['id'];
    $namakategori = $_POST['name'];

    mysqli_query($koneksi,"update category_tb set name='$namakategori' where id='$id'");

    header("location:kategori.php");


	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from category_tb where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 mt-3" style="min-height:480px">
                    <div class="card">
                        <div class="card-header">
                            EDIT KATEGORI
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <form method="post" action="">
			                            <div class="from-group">
				                			
					                        <label>Nama Kategori</label>
						                        <input type="hidden" class="form-control" name="id" value="<?php echo $d['id']; ?>">
						                        <input type="text" class="form-control" name="name" value="<?php echo $d['name']; ?>">

			                            </div>
                                            <td><input type="submit" class="btn btn-primary" value="selesai"></td>
		                            </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
	<?php 
	    }
        include "footer.php";
	?>
