<?php 
// koneksi database
include 'header.php';

// menangkap data id yang di kirim dari url
$id = $_GET['id'];


// menghapus data dari database
mysqli_query($koneksi,"delete from category_tb where id='$id'");

// mengalihkan halaman kembali ke index.php
header("location:ketegori.php");
exit();
?>