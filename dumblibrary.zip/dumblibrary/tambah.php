<?php
    include "header.php";
?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-3" style="min-height:480px;">
            <div class="card">
                <div class="card-header">
                TAMBAH DATA BUKU</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <form action="create.php" method="POST" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>Judul</label>
                                    <input type="text" class="form-control" name="nama">
                                    <label>Kategori</label>
                                    

                                    <label>Penulis</label>
                                    <input type="text" class="form-control" name="writer_id">
                                    <label>Tahun Terbit</label>
                                    <input type="text" class="form-control" name="publication_year">
                                    <label>Gambar</label>
                                    <input type="file" class="form-control" name="img">
                                    
                                </div>
                                    <input type="submit" class="btn btn-primary" value="simpan">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    include "footer.php";
?>